<?php

use App\Http\Controllers\MqttController;
use Illuminate\Support\Facades\Route;

Route::post('/publish', [MqttController::class, 'publish']);
